// Guard so ad scripts never load in the Lovable editor preview / dev.
// They run only in production builds on non-preview hostnames.
export function adsEnabled(): boolean {
  if (typeof window === "undefined") return false;
  if (!import.meta.env.PROD) return false;
  const h = window.location.hostname;
  if (
    h.startsWith("id-preview--") ||
    h.startsWith("preview--") ||
    h.endsWith(".lovableproject.com") ||
    h.endsWith(".lovableproject-dev.com") ||
    h.endsWith(".beta.lovable.dev") ||
    h === "localhost" ||
    h === "127.0.0.1"
  ) {
    return false;
  }
  return true;
}

export const DIRECT_LINK_URL =
  "https://www.effectivecpmnetwork.com/ba1598zhi?key=3b54760fa9e4f6a238cdbde34f0ac8a2";

// --- Admin-aware ads gate --------------------------------------------------
//
// Admins should never see ads anywhere on the site. This hook wraps
// adsEnabled() with a check against the current user's role in
// public.user_roles, and re-evaluates whenever auth state changes.
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

let cachedIsAdmin: boolean | null = null;

async function checkIsAdmin(userId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) {
    console.error("[ads] admin role check failed, defaulting to showing ads:", error.message);
    return false;
  }
  return !!data;
}

/**
 * Returns true if ads should render for the current visitor.
 * Always false for signed-in admins, regardless of environment.
 */
export function useAdsEnabled(): boolean {
  const [isAdmin, setIsAdmin] = useState<boolean>(cachedIsAdmin ?? false);

  useEffect(() => {
    let cancelled = false;

    const evaluate = async (userId: string | undefined) => {
      if (!userId) {
        cachedIsAdmin = false;
        if (!cancelled) setIsAdmin(false);
        return;
      }
      const admin = await checkIsAdmin(userId);
      cachedIsAdmin = admin;
      if (!cancelled) setIsAdmin(admin);
    };

    supabase.auth.getSession().then(({ data }) => evaluate(data.session?.user?.id));

    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      evaluate(s?.user?.id);
    });

    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, []);

  if (isAdmin) return false;
  return adsEnabled();
}