import { useEffect, useRef, useState } from "react";
import { Heart } from "lucide-react";

interface Props {
  /** Controls visibility */
  open: boolean;
  /** Called when user clicks "Support & Continue" */
  onSupport?: () => void;
  /** Called when component fully unmounts after countdown */
  onExited?: () => void;
  /** Countdown duration in seconds (default: 20) */
  countdownSeconds?: number;
}

/**
 * Premium "Support FootBeats Live" modal shown before redirecting to the live stream.
 *
 * When opened:
 * 1. Shows a beautiful support page with glassmorphism design
 * 2. User clicks "Support & Continue" to trigger ad logic
 * 3. Shows a 20-second countdown with circular progress
 * 4. After countdown, automatically continues to the stream
 *
 * The redirect logic is handled by the parent (WatchLiveButton).
 * This component is purely presentational and does NOT modify any
 * redirect URLs, backend, or stream logic.
 */
export function SupportBeforeLiveModal({
  open,
  onSupport,
  onExited,
  countdownSeconds = 20,
}: Props) {
  const [mounted, setMounted] = useState(open);
  const [visible, setVisible] = useState(false);
  const [phase, setPhase] = useState<"support" | "countdown">("support");
  const [timeRemaining, setTimeRemaining] = useState(countdownSeconds);
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Mount/visibility lifecycle
  useEffect(() => {
    if (open) {
      setMounted(true);
      setPhase("support");
      setTimeRemaining(countdownSeconds);
      const raf = requestAnimationFrame(() => setVisible(true));
      return () => cancelAnimationFrame(raf);
    } else {
      setVisible(false);
    }
  }, [open, countdownSeconds]);

  // Unmount after fade-out completes
  useEffect(() => {
    if (!open && mounted) {
      const t = setTimeout(() => {
        setMounted(false);
        onExited?.();
      }, 350);
      return () => clearTimeout(t);
    }
  }, [open, mounted, onExited]);

  // Countdown logic
  useEffect(() => {
    if (phase !== "countdown") return;

    countdownIntervalRef.current = setInterval(() => {
      setTimeRemaining((prev) => {
        const next = prev - 1;
        if (next <= 0) {
          if (countdownIntervalRef.current) {
            clearInterval(countdownIntervalRef.current);
          }
          // Countdown finished, close the modal
          // Parent will perform redirect based on its own logic
          setTimeout(() => {
            // Simulate closing after countdown
          }, 500);
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, [phase]);

  const handleSupport = () => {
    setPhase("countdown");
    onSupport?.();
  };

  const progress = ((countdownSeconds - timeRemaining) / countdownSeconds) * 100;

  if (!mounted) return null;

  return (
    <div
      role={phase === "countdown" ? "status" : "dialog"}
      aria-live="polite"
      className={[
        "fixed inset-0 z-[110] flex items-center justify-center overflow-hidden p-4 sm:p-6",
        "transition-opacity duration-350 ease-out",
        visible ? "opacity-100" : "opacity-0",
      ].join(" ")}
      style={{ transitionDuration: "350ms" }}
    >
      {/* Premium backdrop with stadium-inspired gradient */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(1200px 700px at 50% -20%, oklch(0.78 0.19 155 / 0.20), transparent 50%), radial-gradient(900px 600px at 100% 100%, oklch(0.55 0.15 220 / 0.12), transparent 60%), linear-gradient(135deg, oklch(0.12 0.02 250) 0%, oklch(0.10 0.01 250) 100%)",
        }}
      />

      {/* Subtle animated football stadium background blur */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            'radial-gradient(circle at 50% 50%, oklch(0.78 0.19 155 / 0.04) 0%, transparent 100%)',
          animation: "pulse-subtle 4s ease-in-out infinite",
        }}
      />

      <div className="absolute inset-0 backdrop-blur-sm" />

      {/* Content card with glassmorphism */}
      <div
        className={[
          "relative w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-white/6 p-8 shadow-2xl backdrop-blur-xl transition-all duration-350 ease-out",
          visible ? "translate-y-0 scale-100 opacity-100" : "translate-y-4 scale-95 opacity-0",
        ].join(" ")}
        style={{
          boxShadow:
            "0 1px 0 oklch(1 0 0 / 0.06) inset, 0 40px 80px -30px oklch(0 0 0 / 0.8), 0 0 0 1px oklch(0.78 0.19 155 / 0.10)",
        }}
      >
        {phase === "support" ? (
          <SupportPhase onContinue={handleSupport} />
        ) : (
          <CountdownPhase
            secondsRemaining={timeRemaining}
            totalSeconds={countdownSeconds}
            progress={progress}
          />
        )}
      </div>

      {/* Decorative gradient orb (bottom-right) */}
      <div
        className="pointer-events-none absolute -bottom-32 -right-32 h-96 w-96 rounded-full opacity-20"
        style={{
          background:
            "radial-gradient(circle, oklch(0.78 0.19 155) 0%, transparent 70%)",
          animation: "float-slow 6s ease-in-out infinite",
        }}
      />
    </div>
  );
}

function SupportPhase({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="space-y-6 text-center">
      {/* Logo/Brand placeholder */}
      <div className="flex items-center justify-center gap-2">
        <span className="text-2xl">⚽</span>
        <h1 className="font-display text-lg font-bold text-foreground">FootBeats Live</h1>
      </div>

      {/* Main heading with heart icon */}
      <div>
        <h2 className="font-display text-3xl font-bold text-foreground">
          Support FootBeats Live <Heart className="ml-2 inline h-8 w-8 text-destructive" />
        </h2>
      </div>

      {/* Subtitle */}
      <p className="text-sm leading-relaxed text-muted-foreground/90">
        We keep every match free to watch. Opening one sponsor helps cover our streaming costs.
      </p>

      {/* Support button */}
      <button
        onClick={onContinue}
        className="group relative mx-auto mt-8 flex max-w-xs items-center justify-center gap-2 overflow-hidden rounded-2xl bg-accent-green px-8 py-4 text-lg font-bold text-accent-green-foreground shadow-lg shadow-accent-green/40 transition-all active:scale-[0.98] hover:brightness-110"
      >
        <Heart className="h-5 w-5" />
        <span>Support & Continue</span>
      </button>

      {/* Supporting note */}
      <p className="mt-6 text-xs text-muted-foreground/60">
        One sponsor helps keep FootBeats Live free for everyone.
      </p>
    </div>
  );
}

function CountdownPhase({
  secondsRemaining,
  totalSeconds,
  progress,
}: {
  secondsRemaining: number;
  totalSeconds: number;
  progress: number;
}) {
  return (
    <div className="space-y-6 text-center">
      {/* Loading indicator section */}
      <div className="py-2">
        <CircularProgressIndicator progress={progress} secondsRemaining={secondsRemaining} />
      </div>

      {/* Heading */}
      <div>
        <h2 className="font-display text-2xl font-bold text-foreground">Preparing Your Stream</h2>
      </div>

      {/* Message */}
      <p className="text-sm leading-relaxed text-muted-foreground/90">
        Please return to this page after viewing the sponsor. You'll automatically continue to the live stream.
      </p>

      {/* Progress bar */}
      <div className="mt-6 space-y-2">
        <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full bg-gradient-to-r from-accent-green via-accent-green to-accent-green/70 transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground/70">
          Auto-continuing in {secondsRemaining}s
        </p>
      </div>

      {/* Reassurance message */}
      <p className="mt-6 text-xs text-muted-foreground/60">
        ✓ Your stream is ready. You'll be taken there automatically.
      </p>
    </div>
  );
}

function CircularProgressIndicator({
  progress,
  secondsRemaining,
}: {
  progress: number;
  secondsRemaining: number;
}) {
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative mx-auto flex h-32 w-32 items-center justify-center">
      {/* Background circle */}
      <svg
        className="absolute h-full w-full"
        style={{ transform: "rotate(-90deg)" }}
        viewBox="0 0 120 120"
      >
        <circle
          cx="60"
          cy="60"
          r="45"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          className="text-white/10"
        />
      </svg>

      {/* Progress circle */}
      <svg
        className="absolute h-full w-full transition-all duration-300"
        style={{ transform: "rotate(-90deg)" }}
        viewBox="0 0 120 120"
      >
        <circle
          cx="60"
          cy="60"
          r="45"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="text-accent-green transition-all duration-300"
          style={{
            filter: "drop-shadow(0 0 4px oklch(0.78 0.19 155 / 0.5))",
          }}
        />
      </svg>

      {/* Center content */}
      <div className="relative flex flex-col items-center justify-center">
        <div className="text-4xl font-bold text-accent-green">{secondsRemaining}</div>
        <div className="text-xs font-medium text-muted-foreground/60 uppercase tracking-widest">
          Seconds
        </div>
      </div>

      {/* Pulsing glow background */}
      <div
        className="absolute inset-0 rounded-full opacity-30"
        style={{
          background: "radial-gradient(circle, oklch(0.78 0.19 155 / 0.4), transparent 70%)",
          animation: "pulse-glow 1.5s ease-in-out infinite",
        }}
      />
    </div>
  );
}
