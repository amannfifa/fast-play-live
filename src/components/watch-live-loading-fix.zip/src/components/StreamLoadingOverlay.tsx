import { useEffect, useState } from "react";

interface Props {
  /** Controls mount + fade-in/out. Parent keeps this mounted until onExited fires. */
  open: boolean;
  /** Called once the fade-out transition has fully finished, so the parent can unmount. */
  onExited?: () => void;
}

/**
 * Full-screen "Opening Live Stream..." overlay shown for a few seconds
 * before the sponsor/redirect flow kicks in. Purely presentational —
 * it never touches redirect logic, URLs, or the ad system.
 */
export function StreamLoadingOverlay({ open, onExited }: Props) {
  const [mounted, setMounted] = useState(open);
  const [visible, setVisible] = useState(false);

  // Mount immediately on open; fade in on next frame for a smooth transition.
  useEffect(() => {
    if (open) {
      setMounted(true);
      const raf = requestAnimationFrame(() => setVisible(true));
      return () => cancelAnimationFrame(raf);
    } else {
      setVisible(false);
    }
  }, [open]);

  // After fade-out completes, unmount and notify the parent.
  useEffect(() => {
    if (!open && mounted) {
      const t = setTimeout(() => {
        setMounted(false);
        onExited?.();
      }, 350); // matches the CSS transition duration below
      return () => clearTimeout(t);
    }
  }, [open, mounted, onExited]);

  if (!mounted) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className={[
        "fixed inset-0 z-[100] flex items-center justify-center overflow-hidden p-6",
        "transition-opacity duration-350 ease-out",
        visible ? "opacity-100" : "opacity-0",
      ].join(" ")}
      style={{ transitionDuration: "350ms" }}
    >
      {/* Backdrop — matches the site's dark green premium palette */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(1000px 600px at 50% -5%, oklch(0.78 0.19 155 / 0.16), transparent 60%), radial-gradient(700px 500px at 100% 100%, oklch(0.55 0.15 220 / 0.10), transparent 60%), oklch(0.13 0.02 250)",
        }}
      />
      {/* Subtle backdrop blur for a glassmorphism feel behind the card */}
      <div className="absolute inset-0 backdrop-blur-sm" />

      <div
        className={[
          "relative w-full max-w-sm rounded-3xl border border-white/10 bg-white/5 p-8 text-center shadow-2xl backdrop-blur-xl",
          "transition-all duration-350 ease-out",
          visible ? "translate-y-0 scale-100 opacity-100" : "translate-y-3 scale-[0.97] opacity-0",
        ].join(" ")}
        style={{
          boxShadow:
            "0 1px 0 oklch(1 0 0 / 0.05) inset, 0 30px 60px -20px oklch(0 0 0 / 0.7), 0 0 0 1px oklch(0.78 0.19 155 / 0.08)",
        }}
      >
        <FootballSpinner />

        <h2 className="font-display mt-6 text-2xl font-bold text-foreground">
          Opening Live Stream…
        </h2>

        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          This stream is supported by sponsors. You may briefly see an advertisement before the live match opens.
        </p>

        <p className="mt-3 text-xs leading-relaxed text-muted-foreground/70">
          If an advertisement appears, simply close it and you'll continue to the live stream.
        </p>

        <ProgressBar active={visible} />

        <p className="mt-4 text-[11px] font-medium uppercase tracking-widest text-accent-green/80">
          Preparing your stream…
        </p>
      </div>
    </div>
  );
}

function FootballSpinner() {
  return (
    <div className="relative mx-auto flex h-20 w-20 items-center justify-center">
      {/* Outer glow pulse */}
      <span
        className="absolute inset-0 rounded-full opacity-60"
        style={{
          background: "radial-gradient(circle, oklch(0.78 0.19 155 / 0.35), transparent 70%)",
          animation: "stream-pulse 1.8s ease-in-out infinite",
        }}
      />
      {/* Rotating ring */}
      <span
        className="absolute inset-0 rounded-full border-2 border-accent-green/25 border-t-accent-green"
        style={{ animation: "stream-spin 0.9s linear infinite" }}
      />
      {/* Football icon, bouncing/pulsing gently */}
      <span
        className="relative flex h-11 w-11 items-center justify-center rounded-full bg-card text-2xl shadow-lg"
        style={{ animation: "stream-bounce 1.4s ease-in-out infinite" }}
        aria-hidden
      >
        ⚽
      </span>
    </div>
  );
}

function ProgressBar({ active }: { active: boolean }) {
  return (
    <div className="mt-6 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
      <div
        className="h-full rounded-full bg-gradient-to-r from-accent-green via-accent-green to-accent-green/70"
        style={{
          width: active ? "100%" : "0%",
          transition: "width 3s cubic-bezier(0.22, 0.61, 0.36, 1)",
        }}
      />
    </div>
  );
}
